﻿6 Fichiers :



1) Le rapport contenant:
	-les faits élémentaires
                        
	-le schéma conceptuel ORM
                        
	-le schéma relationnel de la base de données 
                        
	-nos choix de conception
                        
(fichier Rapport.pdf)


2) Le schéma conceptuel ORM 
(fichier schemaORM.pdf)



3) Le schéma conceptuel ORM avec population 
(fichier ORM_pop.pdf)



4) La base de données qui est remplie avec quelques données représentatives(fichier BDDRelationelle.sqlite)


5)Ensemble des requetes réalisées sur la base de données + création de celle-ci (fichier ORM-to-BDDRelationelle.txt)

6) Les faits élémentaires avec des exemples ( Nous avons rajouté ce fichier car dans les consignes, il demande des exemples concrets )  
(fichier Faits élémentaires avec exemples.pdf)
